﻿using System.Collections.Generic;
using System.Windows.Input;
using SimpleMVVM.Models;

namespace SimpleMVVM.ViewModels
{
    public class PersonsViewModel
    {
        public PersonModel NewPerson { get; set; } = new PersonModel();

        public IList<PersonModel> Persons { get; set; }

        public ICommand AddPersonCommand { get; set; }
        
    }
}