﻿using System;

namespace CleanCodeSample.Fixed
{
    public class ProgramFixed
    {
        public static void RunAdditionProblem()
        {
            MathProblem mathProblem = ReadMathProblem();

            int userAnswer = ReadNumber("Zadejte Vaši odpověď: ");

            if (IsAnswerCorrect(mathProblem, userAnswer))
            {
                PrintMessage(ConsoleColor.Green, String.Format("Vaše odpověď \"{0}\" byla správná", userAnswer));
            }
            else
            {
                PrintMessage(ConsoleColor.Red, String.Format("Vaše odpověď \"{0}\" byla nesprávná", userAnswer));
            }

            WaitForUserInput();
        }

        private static bool IsAnswerCorrect(MathProblem mathProblem, int answer)
        {
            return (mathProblem.Solution == answer);
        }

        private static MathProblem ReadMathProblem()
        {
            MathProblem mathProblem = new MathProblem();

            mathProblem.Operand1 = ReadNumber("Zadejte 1. číslo pro sčítání: ");
            mathProblem.Operand2 = ReadNumber("Zadejte 2. číslo pro sčítání: ");

            return mathProblem;
        }

        public static int ReadNumber(string message = "Zadejte číslo: ")
        {
            int number;
            
            do
            {
                Console.Write(message);
            }
            while (!int.TryParse(Console.ReadLine(), out number));

            return number;
        }

        public static void PrintMessage(ConsoleColor color, string message)
        {
            ConsoleColor originalColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.Write(message);
            Console.ForegroundColor = originalColor;
        }

        private static void WaitForUserInput()
        {
            Console.ReadKey();
        }
    }
}