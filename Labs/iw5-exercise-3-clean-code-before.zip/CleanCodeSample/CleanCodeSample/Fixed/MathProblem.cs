﻿namespace CleanCodeSample.Fixed
{
    public class MathProblem
    {
        public int Operand1 { get; set; }
        public int Operand2 { get; set; }

        public int Solution
        {
            get
            {
                return Operand1 + Operand2;
            }
        }
    }
}