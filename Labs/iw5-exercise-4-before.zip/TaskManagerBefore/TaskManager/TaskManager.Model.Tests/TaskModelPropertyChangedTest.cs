﻿using System.Collections.Generic;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using TaskManager.Model.Tasks;

namespace TaskManager.Model.Tests
{
    [TestClass]
    public class TaskModelPropertyChangedTest
    {
        [TestMethod]
        public void TestPropertyChangedEventIsNotRaisedIfSetSameValueName()
        {
            var receivedEvents = new List<string>();
            string taskName = "Testovací task";
            var task = new TaskModel { Name = taskName };

            task.PropertyChanged += (sender, e) => receivedEvents.Add(e.PropertyName);

            task.Name = taskName;
            Assert.AreEqual(0, receivedEvents.Count);
        }

        [TestMethod]
        public void TestPropertyChangedEventIsRaisedIfSetValueName()
        {
            var receivedEvents = new List<string>();
            string taskName = "Testovací task";
            var task = new TaskModel { Name = taskName };

            task.PropertyChanged += (sender, e) => receivedEvents.Add(e.PropertyName);

            task.Name = string.Format("New {0}", taskName);
            Assert.AreEqual(1, receivedEvents.Count);
        }

        [TestMethod]
        public void TestPropertyChangedEventIsRaisedIfSetValuePercentDoneForTaskGroup()
        {
            var receivedEvents = new List<string>();
            var task = new TaskModel { Name = "Testovací task" };

            var task1 = new TaskModel { Name = "Testovací subtask 1", PercentDone = 60 };
            var task2 = new TaskModel { Name = "Testovací subtask 2", PercentDone = 40 };
            var task3 = new TaskModel { Name = "Testovací subtask 3", PercentDone = 50 };
            task.Add(task1);
            task.Add(task2);
            task.Add(task3);

            task.PropertyChanged += (sender, e) => receivedEvents.Add(e.PropertyName);

            task.Tasks.First().PercentDone = 70;
            Assert.AreEqual(1, receivedEvents.Count);
        }

        [TestMethod]
        public void TestPropertyChangedEventIsRaisedIfSetValuePercentDoneForTaskSimple()
        {
            var receivedEvents = new List<string>();
            var task = new TaskModel { Name = "Testovací task", PercentDone = 60 };

            task.PropertyChanged += (sender, e) => receivedEvents.Add(e.PropertyName);

            task.PercentDone = 70;
            Assert.AreEqual(1, receivedEvents.Count);
        }
    }
}