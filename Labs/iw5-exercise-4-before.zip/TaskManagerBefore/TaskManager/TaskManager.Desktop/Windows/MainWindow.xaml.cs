﻿using System.ComponentModel;
using System.Windows;

using TaskManager.ViewModels.ViewModels;

namespace TaskManager.Desktop.Windows
{
    /// <summary>
    ///     Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private TasksViewModel viewModel;

        public MainWindow()
        {
            this.InitializeComponent();
            this.viewModel = (TasksViewModel)this.MainGrid.DataContext;
            this.Loaded += this.MainWindowLoaded;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            this.viewModel.SaveData();
            this.viewModel.Dispose();
        }

        private void AddTaskButton_OnClick(object sender, RoutedEventArgs e)
        {
            AddTaskDialogWindow addTaskDialog = new AddTaskDialogWindow();
            addTaskDialog.ShowDialog();
        }

        private void ItemsListBox_OnLoaded(object sender, RoutedEventArgs e)
        {
            if (this.ItemsListBox.Items.Count > 0)
            {
                this.ItemsListBox.SelectedIndex = 0;
            }
        }

        private void MainWindowLoaded(object sender, RoutedEventArgs e)
        {
            this.viewModel.LoadData();
        }
    }
}