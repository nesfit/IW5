namespace TaskManager.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initialcommit : DbMigration
    {
        public override void Up()
        {
            this.CreateTable(
                "dbo.Persons",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        Firstname = c.String(),
                        Lastname = c.String(),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.ID);

            this.CreateTable(
                "dbo.Tasks",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        PercentDone = c.Int(nullable: false),
                        Description = c.String(),
                        Name = c.String(),
                        Assign_ID = c.Guid(),
                        ParentTask_ID = c.Guid(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Persons", t => t.Assign_ID)
                .ForeignKey("dbo.Tasks", t => t.ParentTask_ID)
                .Index(t => t.Assign_ID)
                .Index(t => t.ParentTask_ID);
            
        }
        
        public override void Down()
        {
            this.DropForeignKey("dbo.Tasks", "ParentTask_ID", "dbo.Tasks");
            this.DropForeignKey("dbo.Tasks", "Assign_ID", "dbo.Persons");
            this.DropIndex("dbo.Tasks", new[] { "ParentTask_ID" });
            this.DropIndex("dbo.Tasks", new[] { "Assign_ID" });
            this.DropTable("dbo.Tasks");
            this.DropTable("dbo.Persons");
        }
    }
}
