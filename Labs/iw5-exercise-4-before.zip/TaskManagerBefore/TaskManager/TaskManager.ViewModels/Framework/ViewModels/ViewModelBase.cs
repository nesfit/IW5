﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;

using TaskManager.Model.Annotations;
using TaskManager.Model.Base.Interface;
using TaskManager.Services;
using TaskManager.Services.Services.Repository;


namespace TaskManager.ViewModels.Framework.ViewModels
{
    public abstract class ViewModelBase<T> : IDisposable
        where T : class, IModel
    {
        private bool disposed;

        public Repository<TaskManagerDbContext, T> Service { get; protected set; }

        ~ViewModelBase()
        {
            this.Dispose(false);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public abstract void LoadData();

        public void SaveData()
        {
            this.Service.Save();
        }

        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.Service.Dispose();
                }
                this.disposed = true;
            }
        }
    }
}