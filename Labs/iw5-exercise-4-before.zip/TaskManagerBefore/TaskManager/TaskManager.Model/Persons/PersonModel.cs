﻿using System.Collections.ObjectModel;

using TaskManager.Model.Base.Implementation;
using TaskManager.Model.Tasks;

namespace TaskManager.Model.Persons
{
    public class PersonModel : BaseModel
    {
        private string firstname;

        private string lastname;

        public PersonModel()
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }

        public string Firstname
        {
            get
            {
                return this.firstname;
            }
            set
            {
                if (this.firstname != value)
                {
                    this.firstname = value;
                    this.OnPropertyChanged();
                    this.OnPropertyChanged("Name");
                }
            }
        }

        public string Lastname
        {
            get
            {
                return this.lastname;
            }
            set
            {
                if (this.lastname != value)
                {
                    this.lastname = value;
                    this.OnPropertyChanged();
                    this.OnPropertyChanged("Name");
                }
            }
        }

        public override string Name
        {
            get
            {
                return string.Format("{0} {1}", this.Firstname, this.Lastname);
            }
        }

        public virtual ObservableCollection<TaskModel> Tasks { get; set; }
    }
}