using System;

using TaskManager.Model.Base.Interface;

namespace TaskManager.Model.Base.Implementation
{
    public abstract class BaseModel : Model, INameModel, IDescriptionModel
    {
        private string description;

        private string name;

        public string Description
        {
            get
            {
                return this.description;
            }
            set
            {
                if (this.description != value)
                {
                    this.description = value;
                    this.OnPropertyChanged();
                }
            }
        }

        public virtual string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                if (this.name != value)
                {
                    this.name = value;
                    this.OnPropertyChanged();
                }
            }
        }

        protected BaseModel()
        {
        }

        protected BaseModel(Guid id)
            : base(id)
        {
        }

        protected int ClipToRange(int min, int max, int value)
        {
            if (value > max)
            {
                return max;
            }
            if (value < min)
            {
                return min;
            }
            return value;
        }
    }
}