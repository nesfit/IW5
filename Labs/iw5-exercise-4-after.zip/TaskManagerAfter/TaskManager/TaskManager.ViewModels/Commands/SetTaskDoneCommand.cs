﻿using TaskManager.Model.Tasks;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;
using TaskManager.ViewModels.ViewModels;

namespace TaskManager.ViewModels.Commands
{
    public class SetTaskDoneCommand : CommandBase<ViewModelCollection<TaskModel>>
    {
        public SetTaskDoneCommand(TasksViewModel viewModelCollection)
            : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            var task = item as TaskModel;
            if (task != null)
            {
                task.PercentDone = 100;
            }
        }
    }
}