using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.Commands
{
    public class AddCommand<T> : CommandBase<ViewModelCollection<T>>
        where T : class, IModel, new()
    {
        public AddCommand(ViewModelCollection<T> viewModelCollection)
            : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.Service.Add(this.ViewModel.NewItem);
            this.ViewModel.Items.Add(this.ViewModel.NewItem);
         
            this.ViewModel.NewItem = new T();
        }
    }
}