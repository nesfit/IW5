using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.Commands
{
    public class RemoveCommand<T> : CommandBase<ViewModelCollection<T>>
        where T : class, IModel, new()
    {
        public RemoveCommand(ViewModelCollection<T> viewModelCollection)
            : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            var typeItem = item as T;
            if (typeItem != null)
            {
                //this.ViewModel.Service.Delete(typeItem);
                this.ViewModel.Items.Remove(typeItem);
            }
        }
    }
}