﻿using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Commands;

namespace TaskManager.ViewModels.Framework.ViewModels
{
    public abstract class ViewModelCollection<T> : ViewModelBase<T>
        where T : class, IModel, new()
    {
        private string status;

        public ICommand Add { get; set; }

        public ObservableCollection<T> Items
        {
            get
            {
                return this.Service.GetObservableCollection();
            }
        }

        public T NewItem { get; set; }

        public ICommand Remove { get; set; }

        public string Status
        {
            get
            {
                return this.status;
            }
            set
            {
                if (this.status != value)
                {
                    this.status = value;
                    this.OnPropertyChanged();
                }
            }
        }

        protected ViewModelCollection()
        {
            this.Status = "Data nebyla načtena";
            this.Remove = new RemoveCommand<T>(this);
            this.Add = new AddCommand<T>(this);
            this.NewItem = new T();
        }

        public async override void LoadData()
        {
            this.Status = "Načítám";
            await Task.Delay(1000);
            this.Service.LoadAll();
            this.Status = "Data načtena";

            OnPropertyChanged("Items");
        }
    }
}