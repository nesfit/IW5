﻿using System.Windows.Input;

using TaskManager.Model.Tasks;
using TaskManager.Services.Services;
using TaskManager.ViewModels.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.ViewModels
{
    public class TasksViewModel : ViewModelCollection<TaskModel>
    {
        public ICommand SetTaskDone { get; private set; }

        public TasksViewModel()
        {
            this.Service = new TaskService();
            this.SetTaskDone = new SetTaskDoneCommand(this);
        }
    }
}