using Microsoft.VisualStudio.TestTools.UnitTesting;

using TaskManager.Model.Persons;

namespace TaskManager.Model.Tests
{
    [TestClass]
    public class PersonModelPropertyChangedTest
    {
        [TestMethod]
        public void TestPropertyChangedEventIsNotRaisedIfSetSameValueFirstName()
        {
            var person = new PersonModel();
            int receivedEventsCount = 0;
            person.PropertyChanged += (sender, e) =>
                {
                    if (e.PropertyName == "Name")
                    {
                        receivedEventsCount++;
                    }
                };
            person.Firstname = "Martin";
            Assert.AreEqual(1, receivedEventsCount);
        }

        [TestMethod]
        public void TestPropertyChangedEventIsNotRaisedIfSetSameValueLastName()
        {
            var person = new PersonModel();
            int receivedEventsCount = 0;
            person.PropertyChanged += (sender, e) =>
                {
                    if (e.PropertyName == "Name")
                    {
                        receivedEventsCount++;
                    }
                };
            person.Lastname = "Dybal";
            Assert.AreEqual(1, receivedEventsCount);
        }

        [TestMethod]
        public void TestPropertyName()
        {
            var person = new PersonModel();
            person.Firstname = "Martin";
            person.Lastname = "Dybal";
            Assert.AreEqual("Martin Dybal", person.Name);
        }
    }
}