﻿using System.Data.Entity;
using System.Data.Entity.Migrations;

using TaskManager.Model.Persons;
using TaskManager.Model.Tasks;

namespace TaskManager.Services
{
    public class TaskManagerDbContext : DbContext
    {
        public DbSet<PersonModel> Persons { get; set; }

        public DbSet<TaskModel> Tasks { get; set; }

        public TaskManagerDbContext()
            : base(@"Data Source=(LocalDB)\v11.0;AttachDbFileName=E:\Skydrive\Work\Teaching\IW5\Cvicenia\04\cv04\TaskManagerAfter\TaskManager\TaskManager.Services\LocalDb.mdf;Persist Security Info=True;MultipleActiveResultSets=True;Integrated Security=SSPI")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<TaskManagerDbContext, TaskManagerDbMigrationsConfiguration<TaskManagerDbContext>>());
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<PersonModel>().ToTable("Persons");
            modelBuilder.Entity<TaskModel>().ToTable("Tasks");

            modelBuilder.Entity<TaskModel>().HasOptional(t => t.ParentTask).WithMany(t => t.Tasks);
        }
    }

    public class TaskManagerDbMigrationsConfiguration<T> : DbMigrationsConfiguration<T>
        where T : DbContext
    {
        public TaskManagerDbMigrationsConfiguration()
        {
            this.AutomaticMigrationsEnabled = true;
        }
    }
}