﻿using SimpleMVVM.Annotations;
using SimpleMVVM.Commands;
using SimpleMVVM.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SimpleMVVM.ViewModels
{
    public class PersonsViewModel : INotifyPropertyChanged
    {
        private Person newPerson;

        public ICommand AddPerson { get; private set; }

        public Person NewPerson
        {
            get
            {
                return this.newPerson;
            }
            set
            {
                if (Equals(value, this.newPerson))
                {
                    return;
                }
                this.newPerson = value;
                this.OnPropertyChanged();
            }
        }

        public ObservableCollection<Person> Persons { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public PersonsViewModel()
        {
            this.NewPerson = new Person();
            this.AddPerson = new AddPersonCommand(this);
            this.Persons = new ObservableCollection<Person>();
        }

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}