using SimpleMVVM.Models;
using SimpleMVVM.ViewModels;
using System;
using System.Windows.Input;

namespace SimpleMVVM.Commands
{
    public class AddPersonCommand : ICommand
    {
        private readonly PersonsViewModel personsViewModel;

        public event EventHandler CanExecuteChanged;

        public AddPersonCommand(PersonsViewModel personsViewModel)
        {
            this.personsViewModel = personsViewModel;
        }

        public bool CanExecute(object parameter)
        {
            return this.personsViewModel.Persons.Count < 3;
        }

        public void Execute(object parameter)
        {
            this.personsViewModel.Persons.Add(this.personsViewModel.NewPerson);
            this.personsViewModel.NewPerson = new Person();

            var onCanExecuteChanged = this.CanExecuteChanged;
            if (onCanExecuteChanged != null)
            {
                onCanExecuteChanged(this, new EventArgs());
            }
        }
    }
}