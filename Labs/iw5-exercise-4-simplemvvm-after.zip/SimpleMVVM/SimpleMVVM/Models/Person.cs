﻿using SimpleMVVM.Annotations;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SimpleMVVM.Models
{
    public class Person : INotifyPropertyChanged
    {
        private string firstname;

        private string lastname;

        public string Firstname
        {
            get
            {
                return this.firstname;
            }
            set
            {
                if (value == this.firstname)
                {
                    return;
                }
                this.firstname = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged("Name");
            }
        }

        public string Lastname
        {
            get
            {
                return this.lastname;
            }
            set
            {
                if (value == this.lastname)
                {
                    return;
                }
                this.lastname = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged("Name");
            }
        }

        public string Name
        {
            get
            {
                return string.Format("{0} {1}", this.Firstname, this.Lastname);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}