using TaskManager.Model.Tasks;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.Commands.Task
{
    public class AddNewTaskCommand : CommandBase<ViewModelCollection<TaskModel>>
    {
        public AddNewTaskCommand(ViewModelCollection<TaskModel> viewModelCollection)
            : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        {
            this.ViewModel.NewItem = new TaskModel();
        }
    }
}