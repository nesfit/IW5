﻿using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.Commands.Collection
{
    public class DiscardItemCommand<T> : CommandBase<ViewModelCollection<T>>
        where T : class, IModel, new()
    {
        public DiscardItemCommand(ViewModelCollection<T> viewModel)
            : base(viewModel)
        {
        }

        public override void Execute(object parameter)
        {
            ViewModel.NewItem = null;
        }
    }
}