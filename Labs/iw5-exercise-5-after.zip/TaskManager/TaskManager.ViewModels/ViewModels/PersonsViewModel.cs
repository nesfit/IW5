﻿using System;
using System.Windows.Input;

using TaskManager.Model.Persons;
using TaskManager.Services.Services;
using TaskManager.ViewModels.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.ViewModels
{
    public class PersonsViewModel : ViewModelCollection<PersonModel>
    {
        public ICommand Cancel { get; set; }

        public PersonsViewModel()
        {
            this.Name = "Persons";

            this.Service = new PersonService();
            base.LoadData();
        }
    }
}