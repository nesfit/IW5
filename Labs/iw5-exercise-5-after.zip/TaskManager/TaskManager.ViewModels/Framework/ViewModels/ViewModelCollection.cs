﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Commands;
using TaskManager.ViewModels.Commands.Collection;

namespace TaskManager.ViewModels.Framework.ViewModels
{
    public abstract class ViewModelCollection<T> : ViewModelBase<T>
        where T : class, IModel, new()
    {
        private string status;

        private T newItem;

        public ICommand SaveNewItem { get; set; }
        public ICommand DiscardNewItem { get; set; }
        public ICommand RemoveItem { get; set; }

        public ObservableCollection<T> Items
        {
            get
            {
                return this.Service.GetObservableCollection();
            }
        }

        public T NewItem
        {
            get
            {
                return newItem;
            }
            set
            {
                if (Equals(value, newItem))
                {
                    return;
                }
                newItem = value;

                OnPropertyChanged();
            }
        }

        public string Status
        {
            get
            {
                return this.status;
            }
            set
            {
                if (this.status != value)
                {
                    this.status = value;
                    this.OnPropertyChanged();
                }
            }
        }

        protected ViewModelCollection()
        {
            this.Status = "Data nebyla načtena";
            this.RemoveItem = new RemoveCommand<T>(this);
            this.SaveNewItem = new SaveItemCommand<T>(this);
            this.DiscardNewItem = new DiscardItemCommand<T>(this);
            this.NewItem = new T();
        }

        public async override void LoadData()
        {
            this.Status = "Načítám";
            await Task.Delay(1000);
            this.Service.LoadAll();
            this.Status = "Data načtena";

            OnPropertyChanged("Items");
        }
    }
}