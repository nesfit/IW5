﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

using TaskManager.Model.Properties;

namespace TaskManager.Model.Base.Implementation
{
    public abstract class Model : INotifyPropertyChanged
    {
        protected Model()
        {
            this.ID = Guid.NewGuid();
        }

        protected Model(Guid id)
        {
            this.ID = id;
        }

        public Guid ID { get; private set; }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = this.PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}