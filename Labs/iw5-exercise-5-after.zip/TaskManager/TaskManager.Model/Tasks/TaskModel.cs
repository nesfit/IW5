using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

using TaskManager.Model.Base.Implementation;
using TaskManager.Model.Persons;

namespace TaskManager.Model.Tasks
{
    public class TaskModel : BaseModel
    {
        private PersonModel assign;

        private TaskModel parentTask;

        private int percentDone;

        public PersonModel Assign
        {
            get
            {
                return this.assign;
            }
            set
            {
                if (this.assign != value)
                {
                    this.assign = value;
                    this.OnPropertyChanged();
                }
            }
        }

        public bool Done
        {
            get
            {
                return (this.percentDone == 100);
            }
        }

        public bool IsMainTask
        {
            get
            {
                return this.ParentTask == null;
            }
        }

        public virtual TaskModel ParentTask
        {
            get
            {
                return this.parentTask;
            }
            set
            {
                if (this.parentTask != value)
                {
                    this.parentTask = value;
                    this.OnPropertyChanged();
                    this.OnPropertyChanged("IsSubtask");
                }
            }
        }

        public int PercentDone
        {
            get
            {
                if (this.Tasks.Any())
                {
                    return this.Tasks.Sum(task => task.PercentDone) / this.Tasks.Count;
                }

                return this.percentDone;
            }
            set
            {
                this.SetPercentDoneSimpleTask(value);

                if (this.Tasks.Any())
                {
                    this.SetPercentDoneMultipleTask(value);
                }
            }
        }

        public virtual ObservableCollection<TaskModel> Tasks { get; private set; }

        public TaskModel()
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }

        public TaskModel(Guid id)
            : base(id)
        {
            this.Tasks = new ObservableCollection<TaskModel>();
        }

        public void Add(TaskModel task)
        {
            this.Tasks.Add(task);
            task.PropertyChanged += this.InnerTaskChanged;
            this.OnPropertyChanged("Tasks");
        }

        public void Remove(TaskModel task)
        {
            this.Tasks.Remove(task);
            task.PropertyChanged -= this.InnerTaskChanged;
            this.OnPropertyChanged("Tasks");
        }

        private void InnerTaskChanged(object sender, PropertyChangedEventArgs args)
        {
            this.OnPropertyChanged(args.PropertyName);
        }

        private void SetPercentDoneMultipleTask(int value)
        {
            foreach (var task in this.Tasks)
            {
                task.PercentDone = value;
            }

            SetOnPropertyChanged();
        }

        private void SetPercentDoneSimpleTask(int value)
        {
            if (this.percentDone != value)
            {
                var percentDoneBefore = this.percentDone;
                this.percentDone = this.ClipToRange(0, 100, value);

                SetOnPropertyChanged(percentDoneBefore);
            }
        }

        private void SetOnPropertyChanged(int percentDoneBefore = 0)
        {
            this.OnPropertyChanged("PercentDone");

            if (this.ParentTask != null)
            {
                this.ParentTask.OnPropertyChanged("PercentDone");
            }

            if ((this.percentDone == 100 && percentDoneBefore != 100)
                || (this.percentDone != 100 && percentDoneBefore == 100))
            {
                this.OnPropertyChanged("Done");
            }
        }
    }
}