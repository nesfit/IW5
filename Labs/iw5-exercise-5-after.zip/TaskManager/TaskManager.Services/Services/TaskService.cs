﻿using TaskManager.Model.Tasks;
using TaskManager.Services.Services.Repository;

namespace TaskManager.Services.Services
{
    public class TaskService : Repository<TaskManagerDbContext, TaskModel>
    {
    }
}