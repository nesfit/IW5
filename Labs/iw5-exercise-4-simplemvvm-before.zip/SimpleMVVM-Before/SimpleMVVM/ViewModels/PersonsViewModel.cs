﻿namespace SimpleMVVM.ViewModels
{
    public class PersonsViewModel
    {
    }
}