﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanCodeSample
{
    class Program
    {
        static void Main(string[] args)
        {
            TestAddition();
        }

        public const string Operand1Prompt = "Zadejte 1. číslo pro sčítání: ";
        public const string Operand2Prompt = "Zadejte 2. číslo pro sčítání: ";
        public const string AnswerUserPrompt = "Zadejte Vaši odpověď: ";
        public const string ResultPrompt = "Vaše odpověď ";
        public const string AnswerCorrectString = " je správná";
        public const string AnswerIncorrectString = " je nesprávná";

        private static void TestAddition()
        {
            int operand1;
            int operand2;
            int answerUser;
            int answerCorrect;

            operand1 = ReadNumberWithPrompt(Operand1Prompt);
            operand2 = ReadNumberWithPrompt(Operand2Prompt);
            answerUser = ReadNumberWithPrompt(AnswerUserPrompt);

            answerCorrect = operand1 + operand2;
            PrintResult(answerUser, (answerUser == answerCorrect));

            Console.ReadKey();
        }

        private static void PrintResult(int answerUser, bool isAnswerCorrect)
        {
            ConsoleColor previousConsoleColor = Console.ForegroundColor;
            
            SetConsoleColorForResult(isAnswerCorrect);
            PrintAnswerUser(answerUser);
            PrintIfAnswerIsCorrect(isAnswerCorrect);

            Console.ForegroundColor = previousConsoleColor;
        }

        private static void PrintAnswerUser(int answerUser)
        {
            Console.Write(ResultPrompt);
            Console.Write(answerUser);
        }

        private static void SetConsoleColorForResult(bool isAnswerCorrect)
        {
            Console.ForegroundColor = isAnswerCorrect ? ConsoleColor.Green : ConsoleColor.Red;
        }

        private static void PrintIfAnswerIsCorrect(bool isAnswerCorrect)
        {
            if (isAnswerCorrect)
            {
                Console.Write(AnswerCorrectString);
            }
            else
            {
                Console.Write(AnswerIncorrectString);                
            }
        }

        private static int ReadNumberWithPrompt(string prompt)
        {
            Console.Write(prompt);

            return ReadNumber();
        }

        private static int ReadNumber()
        {
            int number;
            while (!int.TryParse(Console.ReadLine(), out number))
            {
            }
            return number;
        }
    }
}
