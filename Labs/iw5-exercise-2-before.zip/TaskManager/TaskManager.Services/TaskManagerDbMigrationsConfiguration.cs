﻿using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace TaskManager.Services
{
    public class TaskManagerDbMigrationsConfiguration<T> : DbMigrationsConfiguration<T>
        where T : DbContext
    {
        public TaskManagerDbMigrationsConfiguration()
        {
            AutomaticMigrationsEnabled = true;
        }
    }
}