﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TaskManager.Model;

namespace TaskManager.Services
{
    public class TaskManagerDbContext : DbContext
    {
        public TaskManagerDbContext()
            : base("LocalFileDatabase")
        {
        }


        public DbSet<TaskModel> Tasks { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<TaskManagerDbContext, TaskManagerDbMigrationsConfiguration<TaskManagerDbContext>>());
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<TaskModel>().ToTable("Tasks");

            modelBuilder.Entity<TaskModel>().HasOptional(t => t.ParentTask).WithMany(t => t.Tasks);
        }
    }
}
