﻿using System;

using TaskManager.Model.Base.Interface;

namespace TaskManager.Model.Base.Implementation
{
    public class BaseModel : IModel, IDescriptionModel
    {
        public Guid Id { get; private set; }

        protected BaseModel()
        {
            this.Id = Guid.NewGuid();
        }

        protected BaseModel(Guid id)
        {
            this.Id = id;
        }

        public string Description { get; set; }
    }
}