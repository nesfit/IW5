﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using TaskManager.Model.Base;
using TaskManager.Model.Base.Implementation;

namespace TaskManager.Model
{
    public class TaskModel : BaseModel
    {
        private int percentDone;

        public TaskModel()
        {
            Tasks = new ObservableCollection<TaskModel>();
        }

        public TaskModel(Guid id)
            : base(id)
        {
            Tasks = new ObservableCollection<TaskModel>();
        }

        public virtual TaskModel ParentTask { get; set; }

        public virtual ObservableCollection<TaskModel> Tasks { get; private set; }

        public void Add(TaskModel task)
        {
            Tasks.Add(task);
        }

        public void Remove(TaskModel task)
        {
            Tasks.Remove(task);
        }

        public int PercentDone
        {
            get
            {
                return percentDone;

                //if (Tasks.Any())
                {
                    
                }
            }
            set
            {
                if (percentDone != value)
                {
                    percentDone = value;

                    if (ParentTask != null)
                    {
                        ParentTask.PercentDone = ParentTask.PercentDone;
                    }
                }
            }
        }
    }
}
