﻿using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.Commands;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.Commands.Collection
{
    public class SaveItemCommand<T> : CommandBase<ViewModelCollection<T>>
        where T : class, IModel, new()
    {
         public SaveItemCommand(ViewModelCollection<T> viewModelCollection)
            : base(viewModelCollection)
        {
        }

        public override void Execute(object item)
        { 
            this.ViewModel.Service.Add(this.ViewModel.NewItem);
            this.ViewModel.Items.Add(this.ViewModel.NewItem);
            this.ViewModel.NewItem = null;
        }
    }
}