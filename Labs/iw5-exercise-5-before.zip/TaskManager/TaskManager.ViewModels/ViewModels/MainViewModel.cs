﻿using System;

using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.ViewModels
{
    public class MainViewModel : ViewModelBase<IModel>
    {
        public PersonsViewModel PersonsViewModel { get; set; }
        public TasksViewModel TasksViewModel { get; set; }

        public MainViewModel()
        {
            this.PersonsViewModel = new PersonsViewModel();
            this.TasksViewModel = new TasksViewModel();
        }

        public override void LoadData()
        {
            this.PersonsViewModel.LoadData();
            this.TasksViewModel.LoadData();
        }

        public override void OnProgramShutdownStarted(object sender, EventArgs e)
        {
            this.PersonsViewModel.SaveData();
            this.TasksViewModel.SaveData();
            
            this.PersonsViewModel.Dispose();
            this.TasksViewModel.Dispose();
        }
    }
}