﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;

using TaskManager.Model.Tasks;
using TaskManager.Services.Services;
using TaskManager.ViewModels.Commands;
using TaskManager.ViewModels.Commands.Task;
using TaskManager.ViewModels.Framework.ViewModels;

namespace TaskManager.ViewModels.ViewModels
{
    public class TasksViewModel : ViewModelCollection<TaskModel>
    {
        public ICommand SetTaskDone { get; private set; }
        public ICommand AddNewTask { get; set; }

        public TasksViewModel()
        {
            InitData();
            InitCommands();
        }

        private void InitData()
        {
            this.Name = "Tasks";
            this.Service = new TaskService();
            base.LoadData();
            //this.NewItem = new TaskModel { IsVisible = false };
            this.NewItem = null;
        }

        private void InitCommands()
        {
            this.AddNewTask = new AddNewTaskCommand(this);
            this.SetTaskDone = new SetTaskDoneCommand(this);
        }
    }
}