﻿namespace TaskManager.Model.Base.Interface
{
    public interface INameModel : IModel
    {
        string Name { get; set; }
    }
}