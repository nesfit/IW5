﻿namespace TaskManager.Model.Base.Interface
{
    public interface IDescriptionModel : IModel
    {
        string Description { get; set; }
    }
}