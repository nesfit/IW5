﻿using System;
using System.ComponentModel;

namespace TaskManager.Model.Base.Interface
{
    public interface IModel : INotifyPropertyChanged
    {
        Guid ID { get; }
    }
}