﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

using Brush = System.Drawing.Brush;
using Brushes = System.Drawing.Brushes;

namespace TaskManager.Desktop.Converters
{
    public class BoolToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isValueTrue = (bool)value;
            if (isValueTrue)
            {
                return new SolidColorBrush(Colors.Green);
            }
            else
            {
                return new SolidColorBrush(Colors.Red);
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Brush valueBrush = value as Brush;

            if (valueBrush != null)
            {
                return (valueBrush == Brushes.Green);
            }
            else
            {
                return false;
            }
        }
    }
}