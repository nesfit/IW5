﻿using System;
using System.ComponentModel;
using System.Windows;

using TaskManager.Model.Base.Implementation;
using TaskManager.Model.Base.Interface;
using TaskManager.ViewModels.Framework.ViewModels;
using TaskManager.ViewModels.ViewModels;

namespace TaskManager.Desktop.Windows
{
    /// <summary>
    ///     Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            this.InitializeComponent();
            
            var dataContextViewModel = DataContext as ViewModelBase<IModel>;
            if (dataContextViewModel != null)
            {
                Dispatcher.ShutdownStarted += dataContextViewModel.OnProgramShutdownStarted;
            }
        }
    }
}